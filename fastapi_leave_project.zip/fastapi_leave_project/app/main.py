from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import SessionLocal
import models, schemas

app = FastAPI()

@app.get("/")
def home():
    return {"message": "FastAPI Leave Project Running"}

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Employee applies for leave
@app.post("/apply_leave")
def apply_leave(leave: schemas.LeaveRequest, db: Session = Depends(get_db)):
    new_leave = models.Leave(
        employee_id=leave.employee_id,
        reason=leave.reason,
        status="PENDING_MANAGER"
    )
    db.add(new_leave)
    db.commit()
    return {"message": "Leave sent to Manager"}

# Manager approves or rejects
@app.put("/manager_action/{leave_id}")
def manager_action(leave_id: int, action: str, db: Session = Depends(get_db)):
    leave = db.query(models.Leave).get(leave_id)

    if action == "approve":
        leave.status = "PENDING_CEO"
        msg = "Sent to CEO"
    else:
        leave.status = "REJECTED_MANAGER"
        msg = "Rejected by Manager"

    db.commit()
    return {"message": msg}

# CEO approves or rejects
@app.put("/ceo_action/{leave_id}")
def ceo_action(leave_id: int, action: str, db: Session = Depends(get_db)):
    leave = db.query(models.Leave).get(leave_id)

    if action == "approve":
        leave.status = "APPROVED"
        msg = "Leave Approved"
    else:
        leave.status = "REJECTED_CEO"
        msg = "Rejected by CEO"

    db.commit()
    return {"message": msg}
