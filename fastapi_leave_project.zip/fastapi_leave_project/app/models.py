from sqlalchemy import Column, Integer, String
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    name = Column(String(50))
    role = Column(String(20))  # employee, manager, ceo


class Leave(Base):
    __tablename__ = "leaves"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer)
    reason = Column(String(100))
    status = Column(String(30))  # PENDING_MANAGER, APPROVED, etc
